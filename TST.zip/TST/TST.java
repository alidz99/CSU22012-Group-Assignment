import java.util.ArrayList;
import java.util.List;
public class TST {

	private TSTNode root;

	// Specifies if we have reached the current node from the left, right
	// or center pointer from the parent node
	private enum NodeDirection {
		LEFT,
		CENTER,
		RIGHT
	}
	public TST() {
		this.root = null;
	}
	public TST(final List<String> words) {
		for (String word : words) {
			this.insert(word);
		}
	}
	public TSTNode getRoot() {
		return root;
	}
	public boolean isEmpty() {
		return this.getRoot() == null;
	}
	public TSTNode insert(final String stringToInsert) {
		root = insert(this.root, stringToInsert.toUpperCase().toCharArray(), 0);
		return getRoot();
	}
	private TSTNode insert(TSTNode node, final char[] word, final int index) {
		final char currentChar = word[index];
		if (node == null) {
			node = new TSTNode(currentChar);
		}
		if (currentChar < node.getCharacter()) {
			node.left = insert(node.getLeft(), word, index);
		}
		else if (currentChar > node.getCharacter()) {
			node.right = insert(node.getRight(), word, index);
		}
		else {

			if (index + 1 < word.length) {
				node.center = insert(node.getCenter(), word, index + 1);
			}
			else {
				node.setEndOfWord(true);
			}
		}
		return node;
	}
	public boolean search(final String wordToSearch) {
		return search(getRoot(), wordToSearch.toUpperCase().toCharArray(), 0);
	}
	
	private boolean search(final TSTNode node, final char[] word, final int index) {

		if (node == null) {
			return false;
		}
		final char currentChar = word[index];
		if (currentChar < node.getCharacter()) {
			return search(node.getLeft(), word, index);
		}
		else if (currentChar > node.getCharacter()) {
			return search(node.getRight(), word, index);
		}
		else {
			if (index == word.length - 1) {
				return node.endOfWord();
			}
			return search(node.getCenter(), word, index+1);
		}
	}
}