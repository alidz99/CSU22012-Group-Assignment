public class TSTNode {

    private Character character;
    private boolean endOfWord;
    TSTNode left;
    TSTNode center;
    TSTNode right;

    public Character getCharacter() {
        return character;
    }
    boolean endOfWord() {
        return endOfWord;
    }
    void setEndOfWord(boolean endOfWord) {
        endOfWord = endOfWord;
    }
    TSTNode getLeft() {
        return left;
    }
    TSTNode getCenter() {
        return center;
    }
    TSTNode getRight() {
        return right;
    }
    TSTNode(final Character character) {
        this(character, false);
    }
    TSTNode(final Character character, final boolean endOfWord) {
        this.character = character;
        this.endOfWord = endOfWord;
        this.left = null;
        this.center = null;
        this.right = null;
    }

    boolean isLeafNode() {
        return this.left == null && this.center == null && this.right == null;
    }
}