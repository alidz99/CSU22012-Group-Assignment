import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class readFile {
	static String fileName = "";
	static int nodes = 0;
	static int edges = 0;
	static double cost = 0;
	static ArrayList<String> stopID = new ArrayList<String>();
	static ArrayList<String> stopID1 = new ArrayList<String>();
	static ArrayList<String> tripID = new ArrayList<String>();
	static ArrayList<Integer> StopIDint = new ArrayList<>();
	static ArrayList<String> tripData = new ArrayList<>();
	static ArrayList<String> arrivalTime = new ArrayList<>();
	static ArrayList<String> arrayOfTrips = new ArrayList<>();
	public static void parseFile() throws IOException
	{
		String file = "stops.txt";
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line;
		try {
			@SuppressWarnings("unused")
			String headerLine = br.readLine();
			while((line=br.readLine())!=null)
			{
				String[] columns = line.split(",");
				stopID.add(columns[0]);
			}

		} 
		catch (Exception e) {
			br.close();
		}
		{
			String file2 = "stop_times.txt";
			BufferedReader br2 = new BufferedReader(new FileReader(file2));
			String line2;
			try {
				@SuppressWarnings("unused")
				String headerLine = br2.readLine();

				while( (line2 = br2.readLine()) != null)
				{
					tripData.add(line2);
				}

			} catch (Exception e) {
				br.close();

			}
			String[] g = stopID.toArray(new String[0]);
			for (int i = 0; i < stopID.size(); i++)
			{
				int j = Integer.parseInt(g[i]);
				StopIDint.add(j);
			}
			file = "stop_times.txt";
			BufferedReader br1 = new BufferedReader(new FileReader(file));
			String line1;
			try {
				@SuppressWarnings("unused")
				String headerLine = br1.readLine();
				while((line1=br1.readLine())!=null)
				{
					String[] columns = line1.split(",");
					tripID.add(columns[0]);
					stopID1.add(columns[3]);
					arrivalTime.add(columns[2]);
				}

			} catch (Exception e) {
				br1.close();
			}
		}


	}
	public static void printTime(String s0)
	{
		for (int i = 0; i < arrivalTime.size(); i++)
		{
			String s1 = arrivalTime.get(i);
			if (s1.equals(s0)) {
				arrayOfTrips.add((tripData.get(i)));
				System.out.println(tripData.get(i));
			}

		}
	}

	public static void main(String[] args) throws IOException {
		GraphWeighted graphWeighted = new GraphWeighted(true);
		String test = " 5:25:00";
		parseFile();        
		printTime(test);

		List<NodeWeighted> nodeList = new ArrayList<>(stopID.size());
		HashMap<String, Integer> hashMap = new HashMap<>();
		for(int i=0; i<stopID.size(); i++) {
			NodeWeighted nodeName = new NodeWeighted(i,stopID.get(i));
			hashMap.put(stopID.get(i),i);
			nodeList.add(nodeName);
		}             
		graphWeighted.DijkstraShortestPath(nodeList.get(0),nodeList.get(1));
	}
}
