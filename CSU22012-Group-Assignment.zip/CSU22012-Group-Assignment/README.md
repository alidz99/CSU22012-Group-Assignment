# CSU22012-Group-Assignment
# link -> https://github.com/alidz99/CSU22012-Group-Assignment
# Ali -> part 2 and 3
# Patrick -> part 1 and 4
# Alex -> the demo
# Ciaran -> the design document



